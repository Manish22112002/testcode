// App.js
import React from 'react';
import ApiExample from './ApiExample';

function App() {
  return (
    <div className="App">
      <ApiExample />
    </div>
  );
}

export default App;
